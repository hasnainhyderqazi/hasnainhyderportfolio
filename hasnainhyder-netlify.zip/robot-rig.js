/* Articulated character renderer. Each image is a separate joint, never a pose frame. */
window.RobotRig=class RobotRig{
 constructor(image){this.parts=[];const cellW=image.width/3,cellH=image.height/2;for(let i=0;i<6;i++){const c=document.createElement('canvas');c.width=cellW;c.height=cellH;const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(image,(i%3)*cellW,Math.floor(i/3)*cellH,cellW,cellH,0,0,cellW,cellH);const a=x.getImageData(0,0,cellW,cellH).data;let l=cellW,r=0,t=cellH,b=0;for(let yy=0;yy<cellH;yy++)for(let xx=0;xx<cellW;xx++)if(a[(yy*cellW+xx)*4+3]>55){l=Math.min(l,xx);r=Math.max(r,xx);t=Math.min(t,yy);b=Math.max(b,yy)}this.parts.push({image:c,x:Math.max(0,l-2),y:Math.max(0,t-2),w:Math.min(cellW-l,r-l+5),h:Math.min(cellH-t,b-t+5)})}this.lookX=0;this.lookY=0;this.head=0;this.bounce=0;this.velocity=0}
 impulse(){this.velocity=-5.5}
 part(c,i,x,y,w,h){const p=this.parts[i];c.drawImage(p.image,p.x,p.y,p.w,p.h,x-w/2,y-h/2,w,h)}
 render(c,ms,s){const t=ms/1000,dt=s.dt||.016,elapsed=s.elapsed/1000,d=s.duration/1000,p=Math.min(elapsed/d,1),env=s.name==='idle'?0:Math.sin(p*Math.PI),motion=s.paused?0:1;this.lookX+=((s.lookX||Math.sin(t*.8)*.16*(s.paused?0:1))-this.lookX)*Math.min(dt*9,1);this.lookY+=((s.lookY||Math.sin(t*.6)*.10*(s.paused?0:1))-this.lookY)*Math.min(dt*9,1);this.velocity+=(-this.bounce*25-this.velocity*7)*dt;this.bounce+=this.velocity*dt;
 let roll=Math.sin(t*1.5)*.025*motion,hop=Math.sin(t*2.2)*10*motion+this.bounce*15,left=.15+Math.sin(t*2.5)*.10*motion,right=-.15-Math.sin(t*2.5+1)*.10*motion,happy=0,headAngle=this.lookX*.12+Math.sin(t*1.1)*.025*motion;
 if(!s.paused){if(s.name==='idle'){const q=(t%8-5)/2;if(q>0&&q<1){const e=Math.sin(q*Math.PI);right-=e*(1.8+Math.sin(t*13)*.22);headAngle+=e*.08;happy=e*.5}}if(s.name==='wave'){right-=env*(2.35+Math.sin(elapsed*17)*.28);left+=env*.25;headAngle+=env*.08;happy=env*.8}if(s.name==='dance'){left+=env*(1.1+Math.sin(elapsed*8)*.65);right-=env*(1.1-Math.sin(elapsed*8)*.65);roll+=Math.sin(elapsed*8)*.12*env;headAngle-=Math.sin(elapsed*8)*.12*env;hop-=Math.abs(Math.sin(elapsed*8))*20*env;happy=env}if(s.name==='laugh'){happy=env;hop+=Math.sin(elapsed*23)*4*env;left+=env*.5;right-=env*.5;headAngle+=env*.1}if(s.name==='boost'){left+=env*2.7;right-=env*2.7;hop-=env*80;happy=env*.3;roll+=Math.sin(elapsed*38)*.012*env}if(s.name==='spin'){roll+=Math.PI*2*(p*p*(3-2*p));left+=env*1.2;right-=env*1.2;happy=env}}
 this.head+=(headAngle-this.head)*Math.min(dt*10,1);c.clearRect(0,0,768,768);c.save();c.translate(384+(s.dragX||0)*.3,404+hop);c.scale(1.12,1.12);c.rotate(roll);
 // Shoulder joints: independent pendulum motion plus arm-specific gestures.
 for(const [i,x,a]of [[2,-100,left],[3,100,right]]){c.save();c.translate(x,54);c.rotate(a);this.part(c,i,0,53,48,125);c.restore()}
 c.save();c.rotate(s.name==='dance'?-Math.sin(elapsed*8)*.04*env:0);const breath=Math.sin(t*2.4)*2.5*motion;this.part(c,1,0,104,164+breath,155-breath);c.restore();
 // Head spring, antenna sway and gaze all have their own transforms.
 c.save();c.translate(0,-57+Math.sin(t*2.2+.5)*3*motion);c.rotate(this.head);c.save();c.translate(0,-118);c.rotate(Math.sin(t*3.4)*.08*motion-this.head*.45);this.part(c,5,0,-26,25,63);c.restore();this.part(c,0,0,0,298,226);
 const blink=motion?1-Math.exp(-Math.pow(((t%4.1)-3.88)/.072,2)):1;const eyeHeight=Math.max(.07,blink)*(1-happy*.46);const gazeX=this.lookX*12,gazeY=this.lookY*8;
 for(const x of [-60,60]){c.save();c.translate(x+gazeX,-4+gazeY);c.scale(1,eyeHeight);this.part(c,4,0,0,43,48);c.restore()}
 // The face screen displays a live expression, coordinated with the image-based eyes.
 c.strokeStyle='#65dfff';c.lineWidth=4;c.lineCap='round';c.shadowColor='#00cfff';c.shadowBlur=8;c.beginPath();c.moveTo(-20,43);c.quadraticCurveTo(0,55+happy*11,20,43);c.stroke();c.shadowBlur=0;c.restore();c.restore()
 }
};
